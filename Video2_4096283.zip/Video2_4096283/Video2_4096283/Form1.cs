using System.Diagnostics;
using static System.Net.WebRequestMethods;

namespace Video2_4096283
{
    public partial class Form1 : Form
    {
        HttpClient httpClient = new HttpClient();

        public Form1()
        {
            InitializeComponent();
        }

        // peligroso: async void debe ser evitado, EXEPTO en eventos.
        private async void button1_Click(object sender, EventArgs e)
        {

            pictureBox1.Visible = true;

            var directorioActual = AppDomain.CurrentDomain.BaseDirectory;
            var destinoBaseSecuencial = Path.Combine(directorioActual, @"Imagen\resultado.secuencial");
            var destinoBaseParalelo = Path.Combine(directorioActual,  "@Imagenes\resultado-paralelo");
            PreparEjecucion(destinoBaseParalelo, destinoBaseSecuencial);

            Console.WriteLine("Inicio");
            List<Imagen> imagenes = ObtenerImagenes();

            // para secuencial
            var SW = new Stopwatch();
            SW.Start();

           foreach (var imagen in imagenes)
            {
                await ProcesarImagen(destinoBaseSecuencial, imagen);
            }

           Console.WriteLine("Secuencial - duracion en segundos: {0}",
                SW.ElapsedMilliseconds/1000.0);

            SW.Reset();
            SW.Start();

            var tareasEnumerable = imagenes.Select(async imagen =>
            {
                await ProcesarImagen(destinoBaseParalelo, imagen);
            });
          

            await Task.WhenAll(tareasEnumerable);
            Console.WriteLine("Paralelo-duracion en segundos: {0}",
                SW.ElapsedMilliseconds / 1000.0);

            SW.Stop();


            pictureBox1.Visible = false;
        }


        private async Task ProcesarImagen(string directorio, Imagen imagen)
        {
            var respusta = await httpClient.GetAsync(imagen.URL);
            var contenido = await respusta.Content.ReadAsByteArrayAsync();

            Bitmap bitmap;
            using(var ms = new MemoryStream(contenido))
            {
                bitmap = new Bitmap(ms);
            }

            bitmap.RotateFlip(RotateFlipType.RotateNoneFlipNone);
            var destino = Path.Combine(directorio, imagen.Nombre);
            bitmap.Save(destino);

        }


        private static List<Imagen> ObtenerImagenes()
        {
            var imagenes = new List<Imagen>();

           
            for (int i = 0; i < 7;  i++)

            {
                imagenes.Add(
                    new Imagen()
                    {
                        Nombre = $"JoyadeCeren {i}.jpg",
                        URL = " https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/ES_JoyadeCeren_06_2011_Estructura_9_Area_2_Tamazcal_2106_zoom_out.jpg/800px-ES_JoyadeCeren_06_2011_Estructura_9_Area_2_Tamazcal_2106_zoom_out.jpg"
                    });
                    new Imagen()
                    {
                        Nombre = "Templo tazumal {i}.jpg",
                        URL = "https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Templo_tazumal.jpg/800px-Templo_tazumal.jpg"
                    };


            }
            return imagenes;

        }

        private void BorrarArchivos(string directorio)
        {
            var archivos = Directory.EnumerateFiles(directorio);
            foreach (var archivo in archivos)
            {
                File.Delete(archivo);
            }
        }

        private void PreparEjecucion(string destinoBaseParalelo,
            string destinoBaseSecuencial)
        {
            if (!Directory.Exists(destinoBaseParalelo))
            {
                Directory.CreateDirectory(destinoBaseParalelo); 
            }

            if (!Directory.Exists (destinoBaseSecuencial))
            {
                Directory.CreateDirectory (destinoBaseSecuencial);
            }

            BorrarArchivos(destinoBaseSecuencial);
            BorrarArchivos (destinoBaseParalelo);


        }


        private async Task<string> procesamientoLargo()
        {
            await Task.Delay(3000); // asincrono
            return "Felipe";
        }

        private async Task RealizarProcesamientoLargoA()
        {
            await Task.Delay(1000); // Asincrona
            Console.WriteLine("Proceso A finalizado");
        }

        private async Task RealizarProcesamientoLargoB()
        {
            await Task.Delay(1000); // Asincrona
            Console.WriteLine("Proceso B finalizado");
        }

        private async Task RealizarProcesamientoLargoC()
        {
            await Task.Delay(1000); // Asincrona
            Console.WriteLine("Proceso C finalizado");
        }
    }
}
