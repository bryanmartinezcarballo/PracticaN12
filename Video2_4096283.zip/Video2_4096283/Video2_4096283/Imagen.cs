﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Video2_4096283
{
    internal class Imagen
    {

        public string Nombre { get; set; } = null;
        public string URL { get; set; } = null;

    }
}
