namespace DataBinding;

public partial class Paginauno : ContentPage
{
	public Paginauno()
	{
		InitializeComponent();
	}
}